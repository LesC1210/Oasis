//
//  DesignableView.swift
//  AssistApp
//
//  Created by EndUser on 7/23/20.
//  Copyright © 2020 Leslie Coney. All rights reserved.
//

import UIKit

@IBDesignable
class DesignableView: UIView {
    @IBInspectable var shadowColor: UIColor = UIColor.clear {
        didSet {
            layer.shadowColor = shadowColor.cgColor
        }
    }
    
    @IBInspectable var shadowRadius: CGFloat = 0 {
        didSet {
            layer.shadowRadius = shadowRadius
        }
    }
    
    @IBInspectable var shadowOpacity: CGFloat = 0 {
        didSet {
            layer.shadowOpacity = Float(shadowOpacity)
        }
    }
    
    @IBInspectable var shadowOffsetY: CGFloat = 0 {
        didSet {
            layer.shadowOffset.height = shadowOffsetY
        }
    }
    @IBInspectable var strokeColor: UIColor = UIColor.clear {
        didSet {
            layer.shadowColor = strokeColor.cgColor
        }
    }
    
}

