//
//  ViewController.swift
//  AssistApp
//
//  Created by EndUser on 7/23/20.
//  Copyright © 2020 Leslie Coney. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet weak var plantName: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var dissolved: UILabel!
    @IBOutlet weak var pH: UILabel!
    @IBOutlet weak var funFact: UILabel!
    
    @IBOutlet weak var pickerView2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tabBarController?.tabBar.items?[1].image = UIImage(named: "branch")
        tabBarController?.tabBar.items?[0].image = UIImage(named: "dash")
        tabBarController?.tabBar.items?[2].image = UIImage(named: "user")
        tabBarController?.tabBar.items?[3].image = UIImage(named: "market")
        
//        imagePicker.delegate = self
     
    }
    
//    @IBAction func phSlider(_ sender: UISlider)
//    {
//        //pH.text = String(sender.value)
//        pH.text =
//    }
    
    @IBOutlet weak var image: UIImageView!
    
    @IBAction func openCam(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true, completion: nil)
    }
    
    var imagePicker = UIImagePickerController()
    
    let plants = ["Cabbage", "Kale", "Broccoli"]
    let Cabbage = ["ph": "pH is 6.2", "temp": "19°C", "DO": "5.7ppm", "fact": "Cabbage reduce the risk of heart disease and cancer!"]
    let kale = ["ph": "pH is 8.1", "temp": "24°C", "DO": "6.0ppm", "fact": "Sweet corn is high in carbs and fiber but low in protien and fat!"]
    let broccoli = ["ph": "pH is 6.8", "temp": "29°C", "DO": "5.1ppm", "fact": "Bell pepper is a great soure of vitamin A, vitamin C, potassium, and iron!"]
    
    //let plantInfo = ["Cabbage": ["ph": "pH is 6.2", "temp": "19°C", "DO": "5.7ppm", "fact": "Cabbagees reduce the risk of heart disease and cancer!"], "Sweet Corn": ["ph": "pH is 8.1", "temp": "24°C", "DO": "6.0ppm", "fact": "Sweet corn is high in carbs and fiber but low in protien and fat!"], "Bell Pepper": ["ph": "pH is 6.8", "temp": "29°C", "DO": "5.1ppm", "fact": "Bell pepper is a great soure of vitamin A, vitamin C, potassium, and iron!"]]

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return plants[row]
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return plants.count
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        plantName.text = plants[row]
        if plants[row] == "Cabbage" {
            temp.text = Cabbage["temp"]
            dissolved.text = Cabbage["DO"]
            pH.text = Cabbage["ph"]
            funFact.text = Cabbage["fact"]
        }
        else if plants[row] == "Sweet Corn" {
            temp.text = kale["temp"]
            dissolved.text = kale["DO"]
            pH.text = kale["ph"]
            funFact.text = kale["fact"]
        }
        else {
            temp.text = broccoli["temp"]
            dissolved.text = broccoli["DO"]
            pH.text = broccoli["ph"]
            funFact.text = broccoli["fact"]
        }
    }
}

//extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
//            image.image = image
//        }
//        dismiss(animated: true, completion: nil)
//    }
//}
